/*document.addEventListener("DOMContentLoaded", function () { 
    // Funzione per la registrazione
    function handleRegister(event) {
        event.preventDefault();

        const username = document.getElementById("register-username").value;
        const password = document.getElementById("register-password").value;

        if (!username || !password) {
            alert("Compila tutti i campi per registrarti.");
            return;
        }

        // Salvataggio del ruolo in base al nome utente (simulazione)
        const role = username.toLowerCase().includes("medico") ? "medico" : "paziente";
        localStorage.setItem("userRole", role);

        alert("Registrazione avvenuta con successo!");

        // Reindirizzamento alla home (index.html)
        window.location.href = "index.html";
    }

    // Funzione per il login
    function handleLogin(event) {
        event.preventDefault();

        const username = document.getElementById("login-username").value;
        const password = document.getElementById("login-password").value;

        if (!username || !password) {
            alert("Inserisci username e password.");
            return;
        }

        // Simulazione autenticazione
        const role = username.toLowerCase().includes("medico") ? "medico" : "paziente";
        localStorage.setItem("userRole", role);

        alert("Accesso effettuato con successo!");

        // Reindirizzamento alla home (index.html)
        window.location.href = "index.html";
    }

    // Assegna le funzioni ai bottoni
    document.getElementById("register-form")?.addEventListener("submit", handleRegister);
    document.getElementById("login-form")?.addEventListener("submit", handleLogin);
});

// Funzione per tornare alla pagina di login
function ReturnLogin() {
    window.location.href = "login.html";
}

document.addEventListener("DOMContentLoaded", function () {
    const userRole = localStorage.getItem("userRole"); // Ruolo dell'utente (medico o paziente)
    const appointmentsList = document.getElementById("appointments-list");
    const appointmentForm = document.getElementById("appointment-form");
    const confirmBookingButton = document.getElementById("confirm-booking");
    let selectedAppointment = null;

    // Mostra la sezione di aggiunta appuntamenti solo per i medici
    if (userRole === "medico") {
        document.getElementById("doctor-section").style.display = "block";
    }

    // Simuliamo il caricamento degli appuntamenti dal "database"
    let appointments = JSON.parse(localStorage.getItem("appointments")) || [];

    function renderAppointments() {
        appointmentsList.innerHTML = "";
        appointments.forEach((appointment, index) => {
            const li = document.createElement("li");
            li.innerHTML = `${appointment.date} - ${appointment.notes} 
                <button class="select-appointment" data-index="${index}" ${userRole === "medico" || appointment.booked ? "disabled" : ""}>Seleziona</button>
                ${appointment.booked ? "✔" : ""}`;

            appointmentsList.appendChild(li);
        });
    }

    renderAppointments();

    // Aggiunta di un nuovo appuntamento (solo per medici)
    if (appointmentForm) {
        appointmentForm.addEventListener("submit", function (event) {
            event.preventDefault();
            const date = document.getElementById("appointment-date").value;
            const notes = document.getElementById("appointment-notes").value;
            const currentDateTime = new Date().toISOString().slice(0, 16);

            if (!date || !notes) {
                alert("Compila tutti i campi.");
                return;
            }

            // Controlla se la data inserita è nel passato
            if (date < currentDateTime) {
                alert("Non puoi fissare un appuntamento in un momento passato.");
                return;
            }

            appointments.push({ date, notes, booked: false });
            localStorage.setItem("appointments", JSON.stringify(appointments));

            renderAppointments();
            appointmentForm.reset();
        });
    }

    // Selezione appuntamento per la prenotazione (solo pazienti)
    document.addEventListener("click", function (event) {
        if (event.target.classList.contains("select-appointment") && userRole === "paziente") {
            selectedAppointment = event.target.getAttribute("data-index");
            confirmBookingButton.style.display = "block";
        }
    });

    // Conferma prenotazione (solo pazienti)
    confirmBookingButton.addEventListener("click", function () {
        if (selectedAppointment !== null) {
            appointments[selectedAppointment].booked = true;
            localStorage.setItem("appointments", JSON.stringify(appointments));
            renderAppointments();
            confirmBookingButton.style.display = "none";
            alert("Prenotazione confermata!");
        }
    });

    // Pulsante Logout
    const logoutButton = document.getElementById("logout");
    if (logoutButton) {
        logoutButton.addEventListener("click", function () {
            window.location.href = "login.html";
        });
    }
});
*/

document.addEventListener("DOMContentLoaded", function () { 
    // Funzione per la registrazione
    function handleRegister(event) {
        event.preventDefault();

        const username = document.getElementById("register-username").value;
        const password = document.getElementById("register-password").value;

        if (!username || !password) {
            alert("Compila tutti i campi per registrarti.");
            return;
        }

        // Salvataggio del ruolo in base al nome utente (simulazione)
        const role = username.toLowerCase().includes("medico") ? "medico" : "paziente";
        localStorage.setItem("userRole", role);

        alert("Registrazione avvenuta con successo!");

        // Reindirizzamento alla home (index.html)
        window.location.href = "index.html";
    }

    // Funzione per il login
    function handleLogin(event) {
        event.preventDefault();

        const username = document.getElementById("login-username").value;
        const password = document.getElementById("login-password").value;

        if (!username || !password) {
            alert("Inserisci username e password.");
            return;
        }

        // Simulazione autenticazione
        const role = username.toLowerCase().includes("medico") ? "medico" : "paziente";
        localStorage.setItem("userRole", role);

        alert("Accesso effettuato con successo!");

        // Reindirizzamento alla home (index.html)
        window.location.href = "index.html";
    }

    // Assegna le funzioni ai bottoni
    document.getElementById("register-form")?.addEventListener("submit", handleRegister);
    document.getElementById("login-form")?.addEventListener("submit", handleLogin);
});

// Funzione per tornare alla pagina di login
function ReturnLogin() {
    window.location.href = "login.html";
}

document.addEventListener("DOMContentLoaded", function () {
    const userRole = localStorage.getItem("userRole"); // Ruolo dell'utente (medico o paziente)
    const appointmentsList = document.getElementById("appointments-list");
    const appointmentForm = document.getElementById("appointment-form");
    const confirmBookingButton = document.getElementById("confirm-booking");
    let selectedAppointment = null;

    // Mostra la sezione di aggiunta appuntamenti solo per i medici
    if (userRole === "medico") {
        document.getElementById("doctor-section").style.display = "block";
    }

    // Simuliamo il caricamento degli appuntamenti dal "database"
    let appointments = JSON.parse(localStorage.getItem("appointments")) || [];

    function renderAppointments() {
        appointmentsList.innerHTML = "";
        appointments.forEach((appointment, index) => {
            const li = document.createElement("li");
            li.innerHTML = `${appointment.date} - ${appointment.notes} 
                <button class="select-appointment" data-index="${index}" 
                ${userRole === "medico" || appointment.booked ? "disabled" : ""}>Seleziona</button>
                ${appointment.booked ? "✔" : ""}`;

            // Solo i medici possono eliminare appuntamenti
            if (userRole === "medico") {
                const deleteBtn = document.createElement("button");
                deleteBtn.innerText = "Elimina";
                deleteBtn.onclick = function () {
                    if (confirm("Sei sicuro di voler eliminare questo appuntamento?")) {
                        appointments.splice(index, 1);
                        localStorage.setItem("appointments", JSON.stringify(appointments));
                        renderAppointments();
                    }
                };
                li.appendChild(deleteBtn);
            }

            appointmentsList.appendChild(li);
        });
    }

    renderAppointments();

    // Aggiunta di un nuovo appuntamento (solo per medici)
    if (appointmentForm && userRole === "medico") {
        appointmentForm.addEventListener("submit", function (event) {
            event.preventDefault();
            const date = document.getElementById("appointment-date").value;
            const notes = document.getElementById("appointment-notes").value;
            const currentDateTime = new Date().toISOString().slice(0, 16);

            if (!date || !notes) {
                alert("Compila tutti i campi.");
                return;
            }

            // Controlla se la data inserita è nel passato
            if (date < currentDateTime) {
                alert("Non puoi fissare un appuntamento in un momento passato.");
                return;
            }

            appointments.push({ date, notes, booked: false });
            localStorage.setItem("appointments", JSON.stringify(appointments));

            renderAppointments();
            appointmentForm.reset();
        });
    }

    // Selezione appuntamento per la prenotazione (solo pazienti)
    document.addEventListener("click", function (event) {
        if (event.target.classList.contains("select-appointment") && userRole === "paziente") {
            selectedAppointment = event.target.getAttribute("data-index");
            confirmBookingButton.style.display = "block";
        }
    });

    // Conferma prenotazione (solo pazienti)
    confirmBookingButton.addEventListener("click", function () {
        if (selectedAppointment !== null) {
            appointments[selectedAppointment].booked = true;
            localStorage.setItem("appointments", JSON.stringify(appointments));
            renderAppointments();
            confirmBookingButton.style.display = "none";
            alert("Prenotazione confermata!");
        }
    });

    // Pulsante Logout
    const logoutButton = document.getElementById("logout");
    if (logoutButton) {
        logoutButton.addEventListener("click", function () {
            window.location.href = "login.html";
        });
    }
});
