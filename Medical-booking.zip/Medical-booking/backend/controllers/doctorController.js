/*// frontend/src/App.js
import React, { useState, useEffect } from "react";

const App = () => {
    const [token, setToken] = useState(null);
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [doctors, setDoctors] = useState([]);
    const [appointments, setAppointments] = useState([]);

    const login = async () => {
        const response = await fetch("/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });
        const data = await response.json();
        if (data.token) {
            setToken(data.token);
            fetchDoctors(data.token);
            fetchAppointments(data.token);
        }
    };

    const fetchDoctors = async (token) => {
        const response = await fetch("/api/doctors/list", {
            headers: { Authorization: `Bearer ${token}` }
        });
        const data = await response.json();
        setDoctors(data);
    };

    const fetchAppointments = async (token) => {
        const response = await fetch("/api/appointments/doctor/1", { // Example doctor ID
            headers: { Authorization: `Bearer ${token}` }
        });
        const data = await response.json();
        setAppointments(data);
    };

    return (
        <div>
            <h1>Medical Booking System</h1>
            {!token ? (
                <div>
                    <input placeholder="Username" onChange={(e) => setUsername(e.target.value)} />
                    <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
                    <button onClick={login}>Login</button>
                </div>
            ) : (
                <div>
                    <h2>Welcome!</h2>
                    <h3>Doctors List</h3>
                    <ul>
                        {doctors.map((doctor) => (
                            <li key={doctor.id}>{doctor.name}</li>
                        ))}
                    </ul>
                    <h3>Appointments</h3>
                    <ul>
                        {appointments.map((appointment) => (
                            <li key={appointment.id}>{appointment.date_time}</li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default App;
*/

const db = require("../config/db");

exports.getDoctors = async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM doctors");
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: "Errore nel recupero dei medici" });
    }
};

exports.getAvailableDoctors = async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM doctors WHERE available = 1");
        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: "Errore nel recupero dei medici disponibili" });
    }
};
