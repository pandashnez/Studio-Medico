// backend/controllers/authController.js
const { generateToken } = require('../config/jwt');
const { createUser, getUserByUsername } = require('../models/userModel');
const bcrypt = require('bcryptjs');

const register = async (req, res) => {
    const { username, password, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const userId = await createUser(username, hashedPassword, role);
    res.json({ userId });
};

const login = async (req, res) => {
    const { username, password } = req.body;
    const user = await getUserByUsername(username);
    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }
    res.json({ token: generateToken(user) });
};

module.exports = { register, login };