// backend/controllers/appointmentController.js
const { createAppointment, getAppointmentsByDoctor, cancelAppointment } = require('../models/appointmentModel');

const bookAppointment = async (req, res) => {
    const { doctorId, dateTime } = req.body;
    if (req.user.role !== 'patient') {
        return res.status(403).json({ message: 'Access denied' });
    }
    const appointmentId = await createAppointment(req.user.id, doctorId, dateTime);
    res.json({ appointmentId });
};

const getDoctorAppointments = async (req, res) => {
    if (req.user.role !== 'doctor') {
        return res.status(403).json({ message: 'Access denied' });
    }
    const appointments = await getAppointmentsByDoctor(req.params.doctorId);
    res.json(appointments);
};

const removeAppointment = async (req, res) => {
    await cancelAppointment(req.params.appointmentId);
    res.json({ message: 'Appointment cancelled' });
};

module.exports = { bookAppointment, getDoctorAppointments, removeAppointment };
