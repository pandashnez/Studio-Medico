require("dotenv").config();
const express = require("express");
const cors = require("cors");
const db = require("./config/db");

// Importazione delle rotte corrette
const doctorRoutes = require("./routes/doctorRoutes");
const authRoutes = require("./routes/authRoutes");
const appointmentRoutes = require("./routes/appointmentRoutes");

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Rotte API
app.use("/api/doctors", doctorRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/appointments", appointmentRoutes);

// Avvio del server
const PORT = process.env.PORT || 3307;
app.listen(PORT, () => console.log(`Server avviato su http://localhost:${PORT}`));