// backend/models/doctorModel.js
const pool = require('../config/db');

const getAvailableDoctors = async () => {
    const [rows] = await pool.query('SELECT * FROM doctors');
    return rows;
};

module.exports = { getAvailableDoctors };
