// backend/models/appointmentModel.js
const pool = require('../config/db');

const createAppointment = async (patientId, doctorId, dateTime) => {
    const [result] = await pool.query(
        'INSERT INTO appointments (patient_id, doctor_id, date_time) VALUES (?, ?, ?)',
        [patientId, doctorId, dateTime]
    );
    return result.insertId;
};

const getAppointmentsByDoctor = async (doctorId) => {
    const [rows] = await pool.query(
        'SELECT * FROM appointments WHERE doctor_id = ?',
        [doctorId]
    );
    return rows;
};

const cancelAppointment = async (appointmentId) => {
    await pool.query('DELETE FROM appointments WHERE id = ?', [appointmentId]);
};

module.exports = { createAppointment, getAppointmentsByDoctor, cancelAppointment };
