// backend/routes/appointmentRoutes.js
const express = require('express');
const { authenticateUser } = require('../middleware/authMiddleware');
const { createAppointment, getAppointmentsByDoctor, cancelAppointment } = require('../models/appointmentModel');

const router = express.Router();

router.post('/book', authenticateUser, async (req, res) => {
    const { doctorId, dateTime } = req.body;
    if (req.user.role !== 'patient') {
        return res.status(403).json({ message: 'Access denied' });
    }
    const appointmentId = await createAppointment(req.user.id, doctorId, dateTime);
    res.json({ appointmentId });
});

router.get('/doctor/:doctorId', authenticateUser, async (req, res) => {
    if (req.user.role !== 'doctor') {
        return res.status(403).json({ message: 'Access denied' });
    }
    const appointments = await getAppointmentsByDoctor(req.params.doctorId);
    res.json(appointments);
});

router.delete('/cancel/:appointmentId', authenticateUser, async (req, res) => {
    await cancelAppointment(req.params.appointmentId);
    res.json({ message: 'Appointment cancelled' });
});

module.exports = router;
