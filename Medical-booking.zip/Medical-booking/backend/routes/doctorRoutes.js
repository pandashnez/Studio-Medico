const express = require("express");
const router = express.Router();
const { getDoctors, getAvailableDoctors } = require("../controllers/doctorController");

// Route per ottenere tutti i medici
router.get("/", getDoctors);

// Route per ottenere solo i medici disponibili
router.get("/available", getAvailableDoctors);

module.exports = router; // ✅ Esportazione corretta del router
