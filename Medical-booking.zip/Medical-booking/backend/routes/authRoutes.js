// backend/routes/authRoutes.js
const express = require('express');
const { generateToken } = require('../config/jwt');
const { createUser, getUserByUsername } = require('../models/userModel');
const bcrypt = require('bcryptjs');

const router = express.Router();

router.post('/register', async (req, res) => {
    const { username, password, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const userId = await createUser(username, hashedPassword, role);
    res.json({ userId });
});

router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await getUserByUsername(username);
    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }
    res.json({ token: generateToken(user) });
});

module.exports = router;
